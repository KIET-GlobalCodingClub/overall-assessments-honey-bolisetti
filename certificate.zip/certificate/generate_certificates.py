import pandas as pd
import pdfkit

# Read Excel file
df = pd.read_excel("excel sheet.xlsx")

# Clean column names (remove spaces)
df.columns = df.columns.str.strip()

# Read HTML template
with open("certificate_template.html", "r", encoding="utf-8") as f:
    template = f.read()

# Loop through rows
for index, row in df.iterrows():
    cert_html = template.replace("{{name}}", str(row["Names"]))
    cert_html = cert_html.replace("{{roll}}", str(row["Roll numbers"]))
    cert_html = cert_html.replace("{{department}}", str(row["Department"]))
    cert_html = cert_html.replace("{{email}}", str(row["E-Mail ID"]))

    # Save as HTML
    filename_html = f"certificate_{row['Names']}.html"
    with open(filename_html, "w", encoding="utf-8") as f:
        f.write(cert_html)

    # Convert to PDF
    filename_pdf = f"certificate_{row['Names']}.pdf"
    pdfkit.from_file(filename_html, filename_pdf)

    print(f"✅ Certificate generated: {filename_pdf}")

print("🎉 All certificates generated successfully!")

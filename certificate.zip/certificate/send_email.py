import os
import re
from pathlib import Path

import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# -------------------------------
# 1. Gmail Setup
# -------------------------------
sender_email = "saiveerabhadara22@gmail.com"   # your Gmail
app_password = "ntlbtvhnshqbshcs"        # your Gmail app password (spaces will be removed automatically)

# -------------------------------
# 2. File paths
# -------------------------------
EXCEL_FILE = "excel sheet.xlsx"              # ensure this file exists in the same folder
TEMPLATE_FILE_PRIMARY = "certificate_template.html"   # preferred name
TEMPLATE_FILE_FALLBACK = "certificare.html"           # fallback present in this repo

root = Path(__file__).resolve().parent
excel_path = root / EXCEL_FILE
template_path = root / TEMPLATE_FILE_PRIMARY
if not template_path.exists():
    template_path = root / TEMPLATE_FILE_FALLBACK

if not excel_path.exists():
    raise FileNotFoundError(f"Excel file not found: {excel_path}")
if not template_path.exists():
    raise FileNotFoundError(f"Template file not found: {template_path}")

# -------------------------------
# 3. Read Excel file
# -------------------------------
df = pd.read_excel(excel_path)
# Normalize column labels to avoid KeyError due to stray spaces/casing
if df.columns is not None:
    df.columns = df.columns.astype(str).str.strip()

# -------------------------------
# 4. Read certificate HTML template
# -------------------------------
with open(template_path, "r", encoding="utf-8") as f:
    template = f.read()

# Helper to safely get a value from a row with fallback keys
def get_val(row, keys, default=""):
    for k in keys:
        if k in row:
            return row[k]
    return default

# Safe filename from person's name
def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9 _-]", "", name)
    return cleaned.strip() or "recipient"

# -------------------------------
# 5. Loop through Excel and send email
# -------------------------------
for index, row in df.iterrows():
    # Try multiple header variants to avoid KeyErrors
    name = str(get_val(row, ["Names", "Name", " names", " Names"]).strip())
    roll = str(get_val(row, ["Roll numbers", "Roll Number", "Roll", "roll number"]).strip())
    department = str(get_val(row, ["Department", "Dept"]).strip())
    email = str(get_val(row, ["E-Mail ID", "Email", "Email ID", "email"]).strip())

    if not email:
        print(f"Skipping row {index}: missing email")
        continue

    # Replace placeholders in template
    cert_html = (template
                 .replace("{{name}}", name)
                 .replace("{{roll}}", roll)
                 .replace("{{department}}", department)
                 .replace("{{email}}", email)
                 .replace("[WINNER NAME]", name))  # also support the current template placeholder

    # Save certificate as HTML file
    filename = f"certificate_{safe_name(name)}.html"
    out_path = root / filename
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(cert_html)

    # -------------------------------
    # 6. Create and send email
    # -------------------------------
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = email
    msg["Subject"] = "Your Certificate"

    body = f"Hello {name},\n\nPlease find your certificate attached.\n\nRegards,\nTeam"
    msg.attach(MIMEText(body, "plain"))

    # Attach certificate file
    with open(out_path, "rb") as f:
        attach = MIMEApplication(f.read(), _subtype="html")
        attach.add_header("Content-Disposition", "attachment", filename=out_path.name)
        msg.attach(attach)

    # Send email
    try:
        password_clean = app_password.replace(" ", "")  # Gmail app passwords must be 16 chars with no spaces
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender_email, password_clean)
            server.send_message(msg)
        print(f"✅ Email sent successfully to {email}")
    except Exception as e:
        print(f"❌ Failed to send email to {email}: {e}")

print("🎉 All certificates generated and sent!")